package variables;

class OtherClass {
	
}